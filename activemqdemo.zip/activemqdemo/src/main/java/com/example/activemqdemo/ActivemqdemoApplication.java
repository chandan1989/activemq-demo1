package com.example.activemqdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivemqdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActivemqdemoApplication.class, args);
	}

}
