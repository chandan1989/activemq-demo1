package com.example.activemqdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActivemqdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
